
# EMOJI MANAGER BOT

Emojis was an emoji management bot for Discord.

It was used by over 20,000 Discord communities, with a total of over 1,500,000 total users. I'm no longer maintaining or hosting the bot, but the code will remain public so that you can run the bot yourself if you'd like to.

This code has not been updated for a long time -- it does not incorporate the newest features or best practices, and it may well stop functioning as the Discord API updates.
## Get all items


| Parameter | Type     | Description                |
| :-------- | :------- | :------------------------- |
| `TOKEN` | `string` | **Required** |


| Parameter | Type     | Description                       |
| :-------- | :------- | :-------------------------------- |
| `Client ID`  | `string` | **Required**|



## Installation

```bash
  git clone https://github.com/itz-princeyt336/Emoji-Manager-Discord-Bot.git
  ```
```bash
  npm install
```
```bash
  node index.js
```
## License

[Proprietary](https://github.com/itz-princeyt336/Emoji-Manager-Discord-Bot/blob/main/license)


## Authors

- [FRIDAY](https://github.com/itz-princeyt336)

